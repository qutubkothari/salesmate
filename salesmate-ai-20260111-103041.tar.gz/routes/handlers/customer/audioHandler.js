// Audio transcription and handling
